host='mysql.clarksonmsda.org'
user='is437'
passwd='is437clarkson'
