from transactions import transactions
t = transactions()
print(t.getopenTId(2))
